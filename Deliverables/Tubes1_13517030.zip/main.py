from display import CongklakApp

if __name__ == "__main__":
    app = CongklakApp(kv_file="Congklak.kv")
    app.run()